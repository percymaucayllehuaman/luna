





const menu_links = document.querySelectorAll('.menu_ul_h a[href^="#"');

menu_links.forEach(menu_link => {
    menu_link.addEventListener("click",function(){
        // menu_link.classList.remove('menu_opened');
        alert("hola");
    });
});


const observer = new IntersectionObserver(
    (entries) => {
    entries.forEach(entry => {
        const id = entry.target.getAttribute("id"); 
        const menu_link = document.querySelector('.menu_ul_h a[href^="#{id}"');
        if(entry.isIntersecting){
            document.querySelector(".menu a.selected").classList.remove("i_active");
            menu_link.classList.add('i_active');
        }
    });
},{rootMargin: "-30% 0px -70% 0px"}
);


function toggle_menu(){
    menu_links.classList.toggle("menu_opened");
}